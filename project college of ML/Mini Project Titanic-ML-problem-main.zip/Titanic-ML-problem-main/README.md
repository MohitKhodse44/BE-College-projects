# Titanic-ML-problem
The sinking of the Titanic is one of the most infamous shipwrecks in history.

While there was some element of luck involved in surviving, it seems some groups of people were more likely to survive than others.

In this challenge, we build a predictive model that answers the question: “what sorts of people were more likely to survive?” using passenger data (ie name, age, gender, socio-economic class, etc).


Titanic: Machine Learning from Disaster


![alt text](https://miro.medium.com/max/620/1*dwkupPHPMHWLvSIgrbMqNA.jpeg "Prediction")
