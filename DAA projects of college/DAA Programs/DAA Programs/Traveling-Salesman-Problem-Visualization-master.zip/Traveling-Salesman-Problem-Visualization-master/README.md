# Traveling Salesman Problem Visualization

An interactive learning tool for the Traveling Salesman Problem and various exact and approximative algorithms used to solve it, including ant colony optimization.
